import React from 'react'

export default function PaymentSuccess() {
  return (
    <div>
        <h1>Order Successfully Placed</h1>
    </div>
  )
}
