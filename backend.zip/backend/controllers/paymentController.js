// const { instance } = require("../server");
const Razorpay = require("razorpay");
var instance = new Razorpay({ key_id: 'rzp_test_DFJaRXBU8oVv1d', key_secret: 'd6axdVRnsscYg4KviGLq0CS3' })
const crypto = require("crypto");

exports.checkout = async (req, res, next) => {

  // console.log(req.body);
  const options = {
    amount: Number(req.body.totalAmount * 100),  // amount in the smallest currency unit
    currency: "INR"
  };
  const order = await instance.orders.create(options);

  res.status(200).json({
    success: true,
    order
  });
}

exports.paymentVerification = async (req, res, next) => {
  console.log(req.body);

  // var instance = new Razorpay({ key_id: 'rzp_test_DFJaRXBU8oVv1d', key_secret: 'd6axdVRnsscYg4KviGLq0CS3' })

  const {razorpay_order_id, razorpay_payment_id, razorpay_signature}= req.body;
  const body = razorpay_order_id +"|"+razorpay_payment_id;

  const expectedSignature = crypto.createHmac('sha256', instance.key_secret)
  .update(body.toString())
  .digest('hex')

  const isAuthenticated = expectedSignature === razorpay_signature;
  if(isAuthenticated){
    //saving in database then 
  //   try {
  //     const order = req.order;
  // res.status(201).json({
  //     success:true,
  //     order
  // })
  // } catch (error) {
  //     res.status(400).json({success: false, message: error.message});
  // }

    res.redirect(`http://localhost:3000/paymentsuccess?reference=${razorpay_payment_id}`);
  }
  else{
    res.status(400).json({
      success: false
    });
  }
  
}